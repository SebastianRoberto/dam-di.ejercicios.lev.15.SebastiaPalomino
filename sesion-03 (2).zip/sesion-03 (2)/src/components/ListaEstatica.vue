<script setup> 



</script>


<template>
    <ul>
    <h5>EJ:ListaEstatica</h5>
        <li>Manzana</li>
        <li>Cereza</li>
        <li>Banana</li>
    </ul>

</template>


<style scope>

</style>