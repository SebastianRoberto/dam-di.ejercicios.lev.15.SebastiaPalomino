<template>
    <div class="parrafo-formato">
        <h5>EJ:ParrafoFormato</h5>
      <p class="text-large highlight">Este es un párrafo</p>
    </div>
  </template>
  
  <style scoped>
  .text-large {
    font-size: 20px; 
  }
  
  .highlight {
    background-color: yellow; 
  }
  </style>
  