<script setup>

</script>


<template>
<p>
<h5>EJ: MensajeEstatico</h5>
Bienvenido al curso de Vue-3
</p>

</template>

<style scope>

</style>