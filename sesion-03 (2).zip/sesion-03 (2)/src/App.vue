<script setup>
import ListaEstatica  from   './components/ListaEstatica.vue';
import MensajeEstatico  from   './components/MensajeEstatico.vue';
import LibroInfo  from   './components/LibroInfo.vue';
import ImagenEstatica from './components/ImagenEstatica.vue';
import TituloDInamico from './components/TituloDInamico.vue';
import ListaTitulos from './components/ListaTitulos.vue';
import ParrafoFormato from './components/ParrafoFormato.vue';
import ImagenConTItulo from './components/ImagenConTItulo.vue';
import CabeceraSesion from './components/CabeceraSesion.vue';
</script>

<template>

  <div>
   Ejercicios
</div>
<CabeceraSesion />
<TituloDInamico></TituloDInamico>
<ListaTitulos />
 <MensajeEstatico></MensajeEstatico>
 <ListaEstatica></ListaEstatica>
 <LibroInfo></LibroInfo>
 <ImagenEstatica></ImagenEstatica>
 <ParrafoFormato />
 <ImagenConTItulo />
 
 
 

</template>

<style scoped></style>
